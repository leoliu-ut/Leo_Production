1. Open the file, click run
2. A main menu showing "continent", "global" and "exit"
3. Using mouse click on each button will rigger different data visualizations
	3.1 Drag the slider or click on the bar will rotate the earth
	3.2 Using "up" and "down" arrow on the keyboard to scale up/down the earth